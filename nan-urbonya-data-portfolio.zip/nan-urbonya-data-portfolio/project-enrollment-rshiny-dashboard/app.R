library(shiny)
ui <- fluidPage('Enrollment Dashboard Placeholder')
server <- function(input, output){}
shinyApp(ui, server)